git checkout  k8s/*
git checkout  grafana/*
git checkout  k8s/kube-state-metrics/*
